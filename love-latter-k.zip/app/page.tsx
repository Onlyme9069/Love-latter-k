"use client";
import React, { useEffect, useRef, useState, useMemo } from "react";
import { motion, useScroll, useTransform, AnimatePresence, useSpring } from "framer-motion";

/* ============================================================
   PALETTE
   Dark Coffee #3B2A22 | Mocha #6F4E37 | Latte #C4A484
   Cream #F8F1E7 | Paper Beige #EADCC8 | Soft Rose #D8A7A7
   ============================================================ */

/* ---------- Hand-drawn SVG flower (no emoji, no PNG) ---------- */
function Flower({ size = 60, hue = "#D8A7A7", center = "#C4A484", rotate = 0, openness = 1 }) {
  // openness 0 -> closed bud, 1 -> fully bloomed
  const petalLen = 18 + openness * 14;
  const petalWidth = 10 + openness * 10;
  const petals = 6;
  return (
    <svg
      width={size}
      height={size}
      viewBox="-50 -50 100 100"
      style={{ transform: `rotate(${rotate}deg)`, display: "block" }}
      aria-hidden="true"
    >
      <g>
        {Array.from({ length: petals }).map((_, i) => {
          const angle = (360 / petals) * i;
          return (
            <ellipse
              key={i}
              cx={0}
              cy={-(petalLen * 0.55)}
              rx={petalWidth}
              ry={petalLen}
              fill={hue}
              opacity={0.92}
              transform={`rotate(${angle})`}
              style={{ transition: "all 0.6s cubic-bezier(.4,0,.2,1)" }}
            />
          );
        })}
        <circle r={7 + openness * 3} fill={center} opacity={0.95} />
        <circle r={3} fill="#3B2A22" opacity={0.35} />
      </g>
    </svg>
  );
}

/* ---------- Falling petal (single ellipse, used in petal rain) ---------- */
function PetalShape({ fill }) {
  return (
    <svg width="100%" height="100%" viewBox="-10 -16 20 32" aria-hidden="true">
      <path
        d="M0,-16 C8,-10 8,8 0,16 C-8,8 -8,-10 0,-16 Z"
        fill={fill}
        opacity={0.85}
      />
    </svg>
  );
}

/* ---------- Stem / leaf SVG ---------- */
function Stem({ height = 120, sway = 0 }) {
  return (
    <svg
      width="40"
      height={height}
      viewBox={`0 0 40 ${height}`}
      style={{ display: "block", overflow: "visible" }}
      aria-hidden="true"
    >
      <path
        d={`M20,${height} C${20 + sway},${height * 0.6} ${20 - sway},${height * 0.3} 20,0`}
        stroke="#7A8450"
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d={`M20,${height * 0.55} C${30 + sway},${height * 0.5} ${36},${height * 0.4} ${30},${height * 0.32}`}
        stroke="#869461"
        strokeWidth="2.5"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d={`M20,${height * 0.75} C${10 - sway},${height * 0.7} ${4},${height * 0.6} ${10},${height * 0.52}`}
        stroke="#869461"
        strokeWidth="2.5"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
}

/* ---------- A bouquet: stem + cluster of blooms, animates open with scroll progress ---------- */
function Bouquet({ progress, palette, flip = false, scale = 1, offsetX = 0 }) {
  // progress: 0 -> 1 local bloom progress
  const bloom = Math.max(0, Math.min(1, progress));
  return (
    <div
      style={{
        position: "relative",
        transform: `scaleX(${flip ? -1 : 1}) scale(${scale}) translateX(${offsetX}px)`,
        transformOrigin: "bottom center",
        opacity: Math.min(1, bloom * 2.2),
        transition: "opacity 0.4s ease-out",
      }}
    >
      <div style={{ position: "absolute", bottom: -4, left: "50%", transform: "translateX(-50%)" }}>
        <Stem height={140} sway={6 * bloom} />
      </div>
      <div
        style={{
          position: "relative",
          transform: `translateY(${(1 - bloom) * 40}px) scale(${0.5 + bloom * 0.5})`,
          transition: "transform 0.2s ease-out",
        }}
      >
        <div style={{ position: "absolute", left: -36, top: 18 }}>
          <Flower size={46} hue={palette[1]} center={palette[3]} rotate={-18} openness={bloom} />
        </div>
        <div style={{ position: "relative", zIndex: 2 }}>
          <Flower size={64} hue={palette[0]} center={palette[3]} rotate={4} openness={bloom} />
        </div>
        <div style={{ position: "absolute", left: 30, top: 26 }}>
          <Flower size={42} hue={palette[2]} center={palette[3]} rotate={22} openness={bloom} />
        </div>
      </div>
    </div>
  );
}

/* ---------- Floating petal rain (canvas-free, DOM-based, perf-tuned) ---------- */
function PetalRain({ count = 24, active = true, dense = false }) {
  const colors = ["#D8A7A7", "#C4A484", "#EADCC8", "#E8C4C4"];
  const petals = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 14 + Math.random() * 22,
        delay: Math.random() * 8,
        duration: 9 + Math.random() * 8,
        rotate: Math.random() * 360,
        spinDir: Math.random() > 0.5 ? 1 : -1,
        drift: 30 + Math.random() * 80,
        color: colors[i % colors.length],
        depth: 0.5 + Math.random() * 0.7,
      })),
    [count]
  );

  if (!active) return null;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        overflow: "hidden",
        pointerEvents: "none",
        zIndex: 5,
      }}
      aria-hidden="true"
    >
      {petals.map((p) => (
        <motion.div
          key={p.id}
          style={{
            position: "absolute",
            top: -60,
            left: `${p.left}%`,
            width: p.size,
            height: p.size,
            opacity: dense ? 0.85 * p.depth : 0.6 * p.depth,
            willChange: "transform",
          }}
          initial={{ y: -60, x: 0, rotate: p.rotate }}
          animate={{
            y: "115vh",
            x: [0, p.drift, -p.drift * 0.6, p.drift * 0.3],
            rotate: p.rotate + p.spinDir * 360,
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "linear",
            x: { duration: p.duration, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <PetalShape fill={p.color} />
        </motion.div>
      ))}
    </div>
  );
}

/* ---------- Paper texture overlay ---------- */
function PaperTexture({ opacity = 0.5 }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        opacity,
        mixBlendMode: "multiply",
        backgroundImage:
          "radial-gradient(circle at 20% 30%, rgba(111,78,55,0.10) 0, transparent 45%), radial-gradient(circle at 80% 70%, rgba(59,42,34,0.10) 0, transparent 50%), repeating-linear-gradient(0deg, rgba(59,42,34,0.025) 0px, rgba(59,42,34,0.025) 1px, transparent 1px, transparent 3px), repeating-linear-gradient(90deg, rgba(59,42,34,0.02) 0px, rgba(59,42,34,0.02) 1px, transparent 1px, transparent 3px)",
        backgroundSize: "100% 100%, 100% 100%, 4px 4px, 4px 4px",
      }}
    />
  );
}

/* ---------- Vignette ---------- */
function Vignette({ strength = 0.55 }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        zIndex: 8,
        background: `radial-gradient(ellipse at center, transparent 45%, rgba(59,42,34,${strength}) 100%)`,
      }}
    />
  );
}

/* ---------- Dried flower decoration (corner ornaments) ---------- */
function DriedFlowerCluster({ style }) {
  return (
    <div style={{ position: "absolute", ...style }} aria-hidden="true">
      <div style={{ position: "relative", display: "flex", alignItems: "flex-end" }}>
        <div style={{ marginRight: -14, transform: "rotate(-12deg)" }}>
          <Flower size={38} hue="#C99A8A" center="#A9745A" openness={1} />
        </div>
        <div style={{ marginRight: -10, transform: "rotate(6deg) translateY(6px)" }}>
          <Flower size={50} hue="#D8A7A7" center="#A9745A" openness={1} />
        </div>
        <div style={{ transform: "rotate(20deg) translateY(-4px)" }}>
          <Flower size={32} hue="#C4A484" center="#A9745A" openness={1} />
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   ENVELOPE COMPONENT
   ============================================================ */
function Envelope({ progress }) {
  // progress 0..1 controls: lift, flap open, letter rise
  const lift = Math.min(1, progress / 0.35);
  const flapOpen = Math.max(0, Math.min(1, (progress - 0.25) / 0.4));
  const letterRise = Math.max(0, Math.min(1, (progress - 0.5) / 0.5));

  const flapRotation = -180 * flapOpen; // flap folds backward/up
  const letterY = 40 - letterRise * 240;
  const letterScale = 0.9 + letterRise * 0.18;
  const letterOpacity = Math.min(1, letterRise * 1.6);

  const envelopeY = -lift * 30;
  const envelopeScale = 1 - lift * 0.04 + flapOpen * 0.02;

  return (
    <div
      style={{
        position: "relative",
        width: "min(86vw, 380px)",
        aspectRatio: "3 / 2",
        transform: `translateY(${envelopeY}px) scale(${envelopeScale})`,
        filter: "drop-shadow(0 18px 40px rgba(59,42,34,0.35))",
      }}
    >
      {/* Letter sliding out from inside */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "8%",
          width: "82%",
          height: "78%",
          transform: `translate(-50%, ${letterY}px) scale(${letterScale})`,
          opacity: letterOpacity,
          zIndex: 2,
          background:
            "linear-gradient(180deg, #FBF6EE 0%, #F8F1E7 100%)",
          borderRadius: "4px",
          boxShadow: "0 10px 30px rgba(59,42,34,0.25)",
          border: "1px solid rgba(196,164,132,0.5)",
        }}
      >
        <PaperTexture opacity={0.4} />
        <div
          style={{
            position: "absolute",
            inset: "10% 8%",
            display: "flex",
            flexDirection: "column",
            gap: "8px",
          }}
        >
          {[0.9, 1, 0.75, 0.95, 0.6].map((w, i) => (
            <div
              key={i}
              style={{
                height: "6%",
                width: `${w * 100}%`,
                background: "rgba(111,78,55,0.18)",
                borderRadius: "2px",
              }}
            />
          ))}
        </div>
      </div>

      {/* Envelope body (back) */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "6px",
          background: "linear-gradient(135deg, #C4A484 0%, #B0916C 100%)",
          boxShadow: "inset 0 0 30px rgba(59,42,34,0.25)",
          zIndex: 1,
          overflow: "hidden",
        }}
      >
        <PaperTexture opacity={0.6} />
      </div>

      {/* Envelope front pocket (bottom triangle) */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 3,
          clipPath: "polygon(0% 100%, 100% 100%, 50% 38%)",
          background: "linear-gradient(160deg, #D8BC9B 0%, #C4A484 100%)",
          boxShadow: "0 -2px 6px rgba(59,42,34,0.12)",
        }}
      >
        <PaperTexture opacity={0.45} />
      </div>

      {/* Envelope side pockets for depth */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 3,
          clipPath: "polygon(0% 0%, 50% 50%, 0% 100%)",
          background: "linear-gradient(120deg, #CDA77F 0%, #BC9871 100%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 3,
          clipPath: "polygon(100% 0%, 50% 50%, 100% 100%)",
          background: "linear-gradient(240deg, #CDA77F 0%, #BC9871 100%)",
        }}
      />

      {/* Flap (top triangle) — folds open */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 4,
          clipPath: "polygon(0% 0%, 100% 0%, 50% 56%)",
          transformOrigin: "50% 0%",
          transform: `rotateX(${flapRotation}deg)`,
          transformStyle: "preserve-3d",
          background: "linear-gradient(200deg, #E2C7A6 0%, #C9A57E 100%)",
          boxShadow: "0 4px 10px rgba(59,42,34,0.18)",
          backfaceVisibility: "hidden",
        }}
      >
        <PaperTexture opacity={0.4} />
        {/* wax seal */}
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: "60%",
            transform: "translate(-50%,-50%)",
            width: 46,
            height: 46,
            borderRadius: "50%",
            background: "radial-gradient(circle at 35% 30%, #D8A7A7, #A9745A 70%)",
            boxShadow: "0 4px 8px rgba(59,42,34,0.35)",
            opacity: 1 - flapOpen,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: "Georgia, serif",
            color: "#F8F1E7",
            fontSize: 20,
            fontWeight: 700,
          }}
        >
          K
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   HANDWRITING ANIMATION FOR LETTER TEXT
   ============================================================ */
function HandwrittenLine({ text, delay = 0, size = "1.25rem", weight = 400, color = "#3B2A22", className = "" }) {
  return (
    <motion.p
      className={className}
      style={{
        fontFamily: "'Caveat', 'Segoe Script', cursive",
        fontSize: size,
        fontWeight: weight,
        color,
        lineHeight: 1.5,
        margin: 0,
      }}
      initial={{ opacity: 0, y: 14, filter: "blur(2px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.6 }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {text}
    </motion.p>
  );
}

/* ============================================================
   MAIN PAGE
   ============================================================ */
export default function LoveLetterPage() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: containerRef });

  // smooth the raw scroll progress
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 60, damping: 20, mass: 0.4 });

  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const unsub = smoothProgress.on("change", (v) => setProgress(v));
    return () => unsub();
  }, [smoothProgress]);

  // ---- Section progress windows (tune these to pace the story) ----
  // 0.00 - 0.10  Hero
  // 0.08 - 0.30  Bouquet bloom
  // 0.28 - 0.45  Petal rain intensifies
  // 0.42 - 0.70  Envelope opens
  // 0.62 - 0.90  Letter reveal
  // 0.88 - 1.00  Final scene

  const clamp01 = (v) => Math.max(0, Math.min(1, v));
  const local = (start, end) => clamp01((progress - start) / (end - start));

  const heroOpacity = 1 - local(0.0, 0.12);
  const heroScale = 1 + progress * 0.15;
  const heroY = -progress * 120;

  const bouquetProgress = local(0.06, 0.3);
  const rainActive = progress > 0.18;
  const rainDense = progress > 0.3 && progress < 0.62;

  const envelopeSceneOpacity = clamp01(local(0.36, 0.46)) - clamp01(local(0.94, 1.0));
  const envelopeProgress = local(0.42, 0.92);

  const letterSceneOpacity = clamp01(local(0.6, 0.7));
  const finalOpacity = local(0.88, 1.0);

  const bgGradient = `linear-gradient(180deg,
    #F8F1E7 0%,
    #EADCC8 ${20 + progress * 10}%,
    #D8A7A7${Math.round(20 + progress * 40)
      .toString()}
    , #C4A484 60%,
    #6F4E37 90%,
    #3B2A22 100%)`;

  return (
    <div
      ref={containerRef}
      style={{
        position: "relative",
        height: "600vh",
        background: "linear-gradient(180deg, #F8F1E7 0%, #EADCC8 30%, #D8A7A7 55%, #C4A484 75%, #6F4E37 92%, #3B2A22 100%)",
        fontFamily: "'Quicksand', system-ui, sans-serif",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&family=Cormorant+Garamond:ital@0;1&family=Quicksand:wght@300;400;500;600&display=swap');
        html { scroll-behavior: smooth; }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 0px; background: transparent; }
      `}</style>

      {/* ===================== FIXED VIEWPORT STAGE ===================== */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          overflow: "hidden",
          zIndex: 0,
        }}
      >
        <PaperTexture opacity={0.5} />
        <PetalRain count={progress > 0.86 ? 50 : rainDense ? 36 : 16} active={rainActive} dense={rainDense} />

        {/* ---------- HERO ---------- */}
        <motion.div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            opacity: heroOpacity,
            transform: `translateY(${heroY}px) scale(${heroScale})`,
            pointerEvents: heroOpacity <= 0.02 ? "none" : "auto",
          }}
        >
          <DriedFlowerCluster style={{ top: "6%", left: "2%" }} />
          <DriedFlowerCluster style={{ bottom: "8%", right: "0%", transform: "scaleX(-1)" }} />

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <Envelope progress={0} />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 1, ease: [0.22, 1, 0.36, 1] }}
            style={{
              marginTop: "1.5rem",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
              fontSize: "clamp(1.5rem, 5vw, 2.6rem)",
              color: "#6F4E37",
              textAlign: "center",
              letterSpacing: "0.02em",
              textShadow: "0 2px 12px rgba(248,241,231,0.6)",
            }}
          >
            Something bloomed for you&hellip;
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, y: [0, 8, 0] }}
            transition={{ delay: 1.4, duration: 2, repeat: Infinity, ease: "easeInOut" }}
            style={{
              marginTop: "2.5rem",
              color: "#A9745A",
              fontSize: "0.85rem",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              fontWeight: 500,
            }}
          >
            scroll
          </motion.div>
        </motion.div>

        {/* ---------- SCENE 1+2: BOUQUET BLOOM ---------- */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            opacity: clamp01(local(0.04, 0.16)) - clamp01(local(0.34, 0.42)),
            pointerEvents: "none",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
              gap: "clamp(8px, 4vw, 40px)",
              transform: `translateY(${(1 - bouquetProgress) * 60}px)`,
            }}
          >
            <Bouquet
              progress={local(0.08, 0.22)}
              palette={["#D8A7A7", "#EADCC8", "#C4A484", "#A9745A"]}
              scale={0.85}
              flip
            />
            <Bouquet
              progress={local(0.12, 0.26)}
              palette={["#E8C4C4", "#D8A7A7", "#F8F1E7", "#A9745A"]}
              scale={1.15}
            />
            <Bouquet
              progress={local(0.16, 0.3)}
              palette={["#C4A484", "#D8A7A7", "#EADCC8", "#A9745A"]}
              scale={0.85}
              flip
            />
          </div>

          <motion.p
            style={{
              position: "absolute",
              bottom: "8%",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
              fontSize: "clamp(1.1rem, 4vw, 1.8rem)",
              color: "#6F4E37",
              opacity: clamp01(local(0.18, 0.28)),
              textAlign: "center",
              padding: "0 1.5rem",
            }}
          >
            ...one petal at a time.
          </motion.p>
        </div>

        {/* ---------- SCENE 3: ENVELOPE OPENING ---------- */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            opacity: envelopeSceneOpacity,
            pointerEvents: "none",
          }}
        >
          <div style={{ perspective: "1200px" }}>
            <Envelope progress={envelopeProgress} />
          </div>
          <motion.p
            style={{
              position: "absolute",
              top: "12%",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
              fontSize: "clamp(1.1rem, 4vw, 1.8rem)",
              color: "#F8F1E7",
              opacity: clamp01(local(0.42, 0.52)) - clamp01(local(0.62, 0.7)),
              textAlign: "center",
              padding: "0 1.5rem",
              textShadow: "0 2px 10px rgba(59,42,34,0.4)",
            }}
          >
            A letter, just for you.
          </motion.p>
        </div>

        {/* ---------- SCENE 4: LETTER REVEAL ---------- */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            opacity: letterSceneOpacity - clamp01(local(0.9, 1.0)),
            pointerEvents: "none",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "min(90vw, 520px)",
              maxHeight: "78vh",
              padding: "clamp(1.5rem, 5vw, 3.5rem) clamp(1.5rem, 6vw, 4rem)",
              background: "linear-gradient(180deg, #FBF6EE 0%, #F4EBDC 100%)",
              borderRadius: "6px",
              boxShadow: "0 24px 60px rgba(59,42,34,0.4), 0 2px 0 rgba(255,255,255,0.6) inset",
              transform: `translateY(${(1 - clamp01(local(0.6, 0.74))) * 60}px) scale(${0.92 + clamp01(local(0.6, 0.74)) * 0.08})`,
              border: "1px solid rgba(196,164,132,0.4)",
              overflowY: "auto",
            }}
          >
            <PaperTexture opacity={0.5} />
            <div style={{ position: "relative", zIndex: 1 }}>
              <HandwrittenLine
                text="My dearest Mrs. Khushi Raj Maheshwari,"
                delay={0.1}
                size="clamp(1.3rem, 4.2vw, 1.9rem)"
                weight={600}
                color="#A9745A"
              />
              <div style={{ height: "1rem" }} />
              <HandwrittenLine
                text="Every day with you feels like finding a new flower in a familiar garden."
                delay={0.35}
                size="clamp(1.1rem, 3.6vw, 1.6rem)"
              />
              <div style={{ height: "0.5rem" }} />
              <HandwrittenLine
                text="You make ordinary moments softer, warmer, and brighter."
                delay={0.6}
                size="clamp(1.1rem, 3.6vw, 1.6rem)"
              />
              <div style={{ height: "0.5rem" }} />
              <HandwrittenLine
                text="Thank you for being my favorite person."
                delay={0.85}
                size="clamp(1.1rem, 3.6vw, 1.6rem)"
              />
              <div style={{ height: "1.5rem" }} />
              <HandwrittenLine
                text="Forever yours,"
                delay={1.1}
                size="clamp(1.1rem, 3.6vw, 1.6rem)"
              />
              <HandwrittenLine
                text="Raj ❤️"
                delay={1.3}
                size="clamp(1.4rem, 4.5vw, 2rem)"
                weight={600}
                color="#A9745A"
              />
            </div>

            {/* corner pressed flower */}
            <div style={{ position: "absolute", bottom: -10, right: -10, opacity: 0.85 }}>
              <Flower size={56} hue="#D8A7A7" center="#A9745A" openness={1} rotate={20} />
            </div>
          </div>
        </div>

        {/* ---------- SCENE 5: FINAL ENDING ---------- */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            opacity: finalOpacity,
            pointerEvents: "none",
            background:
              finalOpacity > 0
                ? `radial-gradient(circle at center, rgba(216,167,167,${0.25 * finalOpacity}) 0%, rgba(59,42,34,${0.7 * finalOpacity}) 100%)`
                : "transparent",
          }}
        >
          <Vignette strength={0.6 * finalOpacity} />
          <div style={{ textAlign: "center", transform: `translateY(${(1 - finalOpacity) * 30}px) scale(${0.9 + finalOpacity * 0.1})` }}>
            <p
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic",
                fontSize: "clamp(2rem, 8vw, 4rem)",
                color: "#F8F1E7",
                margin: 0,
                textShadow: "0 4px 20px rgba(59,42,34,0.5)",
              }}
            >
              For Khushi 🌸
            </p>
            <p
              style={{
                marginTop: "1rem",
                fontFamily: "'Caveat', cursive",
                fontSize: "clamp(1.2rem, 4vw, 1.8rem)",
                color: "#EADCC8",
                opacity: 0.9,
              }}
            >
              Made with love by Raj
            </p>
          </div>
        </div>
      </div>

      {/* Spacer content to drive scroll (invisible, defines scroll length) */}
      <div style={{ position: "relative", height: "100%", zIndex: -1 }} />
    </div>
  );
}
